public class Exercicio5 {
    public static void main(String[] args) {
        int contador = 1;

        for (contador = 0; contador < 50; contador++) {
            if (contador % 2 != 0) {
                System.out.println(contador);
            }

        }
    }
}