# Lista de Exercícios I: Estrutura Sequencial

| Nome                           | RA         |
| ------------------------------ | ---------- |
| Caio Alves Fernandes           | 4231925609 |
| Nicholas Breno Campolina Alves | 4231925745 |
| Vitor Emanuel Pereira da Silva | 323112102  |
| Paulo Vítor Amorim de Oliveira | 323114192  |
| Phillipe W.R Sodré             | 4231925672 |
